import {YELLOW} from 'farrapa-colors'

const aTryOnInit = (foo) => {
  console.log(YELLOW(`Calling a-try-on-init's aTryOnInit(${foo})`))
}

export {aTryOnInit}