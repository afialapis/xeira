const {bothPkg} = require('../../src/cjs/index.cjs')

const expect= global.expect
describe('both-pkg', function () {
  this.timeout(100)

  it("check bothPkg", () => {   
    const total = bothPkg()
    expect(total).to.equal(99.99 + 33.33)
  }) 
})