const {bothPkg} = require('./esm_pkg.cjs')

const expect= global.expect

describe('both-pkg: Some foo tests', function () {
  this.timeout(100)

  it("check bothPkg", async () => {   
    const total = await bothPkg()
    expect(total).to.equal(99.99 + 33.33)
  })  
})