"use strict";

// Wrapper for dynamic import() of ESM-only packages.
// Only works in later versions of Node.js 12+

let _bothPkg;
const _getbothPkg = async () => {
  if (!_bothPkg) {
    _bothPkg = await import("../../src/mjs/index.mjs");
  }

  return _bothPkg;
};

const bothPkg = async (...args) => {
  const _bothPkgImpl = await _getbothPkg();
  return _bothPkgImpl.bothPkg(...args);
};

// Test helper: We need to resolve all ESM-only dynamic imports before
// mocking, so just call them here.
const _resolve = async () => Promise.all([
  _getbothPkg()
]);

module.exports = {
  _resolve,
  bothPkg
};
