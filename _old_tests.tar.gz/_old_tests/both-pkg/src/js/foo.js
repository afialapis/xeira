function fooit(obj) {
  obj.foo= 'bar'
  return obj
}

export {
  fooit
}